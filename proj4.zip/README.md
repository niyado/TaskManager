# TaskManager

A basic UWP task manager application with a Web API.

